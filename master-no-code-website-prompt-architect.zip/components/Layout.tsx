
import React from 'react';
// Fix: Added missing 'Zap' import from 'lucide-react'
import { Layout as LayoutIcon, Terminal, BookOpen, Github, Zap } from 'lucide-react';
import { AppTab } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 glass-morphism border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab(AppTab.BUILDER)}>
              <div className="bg-indigo-600 p-2 rounded-lg">
                <Terminal className="text-white" size={24} />
              </div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">
                PromptArchitect
              </span>
            </div>
            
            <nav className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => setActiveTab(AppTab.BUILDER)}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === AppTab.BUILDER ? 'text-indigo-600 bg-indigo-50' : 'text-slate-600 hover:text-indigo-600'}`}
              >
                <LayoutIcon size={18} /> Master Builder
              </button>
              <button 
                onClick={() => setActiveTab(AppTab.TEMPLATES)}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === AppTab.TEMPLATES ? 'text-indigo-600 bg-indigo-50' : 'text-slate-600 hover:text-indigo-600'}`}
              >
                <BookOpen size={18} /> Industry Templates
              </button>
              <button 
                onClick={() => setActiveTab(AppTab.RESOURCES)}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === AppTab.RESOURCES ? 'text-indigo-600 bg-indigo-50' : 'text-slate-600 hover:text-indigo-600'}`}
              >
                <Zap size={18} /> Best Tools
              </button>
            </nav>

            <div className="flex items-center gap-4">
               <a href="https://github.com" target="_blank" className="p-2 text-slate-500 hover:text-indigo-600 transition-colors">
                 <Github size={20} />
               </a>
               <button 
                onClick={() => setActiveTab(AppTab.BUILDER)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-all shadow-md hover:shadow-lg"
               >
                 Start Building
               </button>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {children}
      </main>

      <footer className="bg-slate-900 text-slate-400 py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Terminal className="text-indigo-400" size={24} />
              <span className="text-white text-lg font-bold">PromptArchitect</span>
            </div>
            <p className="max-w-xs text-sm leading-relaxed">
              Empowering creators to build production-ready websites using advanced AI prompt engineering. 
              Optimized for Gemini, Google AI Studio, and modern no-code builders.
            </p>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => setActiveTab(AppTab.BUILDER)} className="hover:text-white transition-colors">Master Prompt</button></li>
              <li><button onClick={() => setActiveTab(AppTab.TEMPLATES)} className="hover:text-white transition-colors">Industry Templates</button></li>
              <li><button onClick={() => setActiveTab(AppTab.RESOURCES)} className="hover:text-white transition-colors">No-Code Tools</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Documentation</a></li>
              <li><a href="#" className="hover:text-white transition-colors">API Guide</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Community</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 mt-8 border-t border-slate-800 text-center text-xs">
          © {new Date().getFullYear()} PromptArchitect Engine. All rights reserved. Professional No-Code Systems.
        </div>
      </footer>
    </div>
  );
};

export default Layout;
