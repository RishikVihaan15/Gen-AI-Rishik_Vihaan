
import React from 'react';
import { 
  Utensils, 
  Stethoscope, 
  Cpu, 
  Plane, 
  Briefcase,
  Layout,
  Terminal,
  Zap
} from 'lucide-react';
import { IndustryTemplate } from './types';

export const INDUSTRY_TEMPLATES: IndustryTemplate[] = [
  {
    id: 'restaurant',
    label: 'Restaurant',
    icon: 'Utensils',
    defaults: {
      type: 'Fine Dining / Casual / Cafe',
      goal: 'Table reservations & customer inquiries',
      audience: 'Local diners, foodies, and tourists',
      style: 'Modern, Elegant, or Cozy',
      features: 'Menu manager, Online Reservation, Location Map, Opening Hours'
    },
    prompt: `You are a Senior Full-Stack Website Builder, UX Designer, Conversion Copywriter, and No-Code Systems Architect.
Build a modern, high-converting restaurant website based on the details below.

Website Name: [[RESTAURANT NAME]]
Restaurant Type: [[Cuisine / Casual / Fine Dining / Cafe / Fast Food]]
Primary Goal: Table reservations & customer inquiries
Target Audience: [[Local diners / tourists / families / professionals]]
Brand Style: [[Modern / Elegant / Casual / Luxury]]

FRONTEND REQUIREMENTS
Create a professional, mobile-first restaurant website with:
• Hero section with signature dish imagery, tagline, and “Book a Table” CTA
• About section with restaurant story & chef introduction
• Menu section (categorized, image-based, prices editable)
• Popular dishes / chef recommendations
• Reservation call-to-action block
• Testimonials & Google review snippets
• Location & opening hours
• FAQ (dietary options, parking, bookings)
• Footer with contact info, social links, and map

BACKEND & ADMIN DASHBOARD
Include an admin panel with:
• Menu manager (add/edit/remove dishes, prices, images)
• Reservation system: Date, time, guests, Admin confirmation & notifications
• Contact form submissions
• Opening hours editor
• CMS for blog posts, announcements, or events
• Full design customization: colors, fonts, layout
• Pre-filled placeholder menu items for instant launch`
  },
  {
    id: 'doctor',
    label: 'Medical/Clinic',
    icon: 'Stethoscope',
    defaults: {
      type: 'Dental / Dermatology / General Practice',
      goal: 'Appointment bookings',
      audience: 'Patients & families',
      style: 'Clean, calm, trustworthy',
      features: 'Patient booking, Doctor profiles, Services overview, FAQ'
    },
    prompt: `You are a Senior Medical Website Architect, UX Designer, and HIPAA-aware No-Code Expert.
Build a professional healthcare website with trust-focused design and booking functionality.

Website Name: [[CLINIC NAME]]
Specialty: [[General Practice / Dental / Dermatology / Specialist]]
Primary Goal: Appointment bookings
Target Audience: Patients & families
Brand Style: Clean, calm, trustworthy

FRONTEND REQUIREMENTS
• Hero section with doctor credibility and “Book Appointment” CTA
• Services / treatments overview
• Doctor profile(s) with qualifications
• Patient benefits & care approach
• Testimonials & FAQ (insurance, availability)
• Contact & location section

BACKEND & ADMIN DASHBOARD
• Appointment booking system: Date, time, service, doctor
• Services & pricing manager
• Doctor profiles editor
• CMS for health articles and updates
• Full admin design customization: Fonts, colors, themes
• Pre-populated placeholder content for immediate use`
  },
  {
    id: 'saas',
    label: 'SaaS',
    icon: 'Cpu',
    defaults: {
      type: 'Automation / AI / Productivity',
      goal: 'Free trials & signups',
      audience: 'Founders, Teams, Enterprises',
      style: 'Modern, tech-forward, minimal',
      features: 'Pricing tables, How it works, Feature grid, Use cases'
    },
    prompt: `You are a Senior SaaS Product Designer, Growth Marketer, and Full-Stack No-Code Engineer.
Build a high-converting SaaS marketing website.

Website Name: [[SAAS NAME]]
Product Type: [[Automation / AI / Productivity / Analytics]]
Primary Goal: Free trials & signups
Target Audience: [[Founders / Teams / Enterprises]]
Brand Style: Modern, tech-forward

FRONTEND REQUIREMENTS
• Hero with value proposition & CTA (“Start Free Trial”)
• How it works (step-based visual guide)
• Feature sections with benefit-focused copy
• Use cases by industry or audience
• Pricing table (Monthly/Yearly toggle)
• Social proof (logos, testimonials)
• FAQ & Conversion-focused footer

BACKEND & ADMIN DASHBOARD
• Content management for features and pages
• Pricing plan editor
• Lead capture forms & CRM integration
• CMS for blog posts, product updates, changelogs
• Complete control over page content and themes
• Pre-filled placeholder pages for immediate publishing`
  },
  {
    id: 'travel',
    label: 'Travel',
    icon: 'Plane',
    defaults: {
      type: 'Travel Agency / Adventure Blog',
      goal: 'Package bookings & inquiries',
      audience: 'Explorers, tourists, vacationers',
      style: 'Vibrant, inspiring, visual-heavy',
      features: 'Package listings, Destination guides, Booking forms'
    },
    prompt: `You are a Senior Travel Platform Architect, UX Designer, and Booking Systems Expert.
Build a travel agency or travel blog website with booking capability.

Website Name: [[TRAVEL BRAND NAME]]
Website Type: [[Agency / Blog / Package Booking]]
Primary Goal: Package bookings & inquiries
Brand Style: Vibrant, inspiring

FRONTEND REQUIREMENTS
• Hero with destination imagery & CTA (“Explore Packages”)
• Popular destinations grid
• Travel packages with pricing & duration
• Detailed package pages
• Offers & limited-time deals
• Blog / travel guides for SEO
• Footer with social feed integration

BACKEND & ADMIN DASHBOARD
• Destination & Package manager
• Booking request dashboard
• Blog & guide editor
• Media library for high-res imagery
• Full content & design customization via admin
• Pre-populated destinations and packages for instant launch`
  },
  {
    id: 'agency',
    label: 'Agency',
    icon: 'Briefcase',
    defaults: {
      type: 'Marketing / Design / Automation',
      goal: 'Lead generation & bookings',
      audience: 'Businesses, Startups, Founders',
      style: 'Premium, bold, modern',
      features: 'Case studies, Service grid, Team section, Booking form'
    },
    prompt: `You are a Senior Brand Strategist, Conversion Copywriter, and Web Architect.
Build a high-converting agency website.

Website Name: [[AGENCY NAME]]
Agency Type: [[Marketing / Design / Automation / Consulting]]
Primary Goal: Lead generation & bookings
Brand Style: Premium, bold, modern

FRONTEND REQUIREMENTS
• Hero with bold positioning & clear value-statement
• Comprehensive services overview
• “How we work” process section
• Case studies / results showcase
• Testimonials & Trust badges
• Strong CTA conversion block
• Professional footer with site map

BACKEND & ADMIN DASHBOARD
• Service & Case Study manager
• Lead intake dashboard
• CMS for insights, whitepapers, or articles
• SEO settings per page
• Full design & branding options (colors, typography)
• Pre-loaded placeholder case studies for instant launch`
  }
];

export const getIcon = (name: string) => {
  const icons: Record<string, any> = { Utensils, Stethoscope, Cpu, Plane, Briefcase, Layout, Terminal, Zap };
  const IconComponent = icons[name] || Layout;
  return <IconComponent size={20} />;
};
