
export interface WebsiteInputs {
  name: string;
  type: string;
  goal: string;
  audience: string;
  features: string;
  style: string;
  colors?: string;
  socialLinks?: string;
  pages?: string;
}

export interface IndustryTemplate {
  id: string;
  label: string;
  icon: string;
  prompt: string;
  defaults: Partial<WebsiteInputs>;
}

export enum AppTab {
  BUILDER = 'builder',
  TEMPLATES = 'templates',
  RESOURCES = 'resources'
}
