
import React, { useState, useCallback } from 'react';
import Layout from './components/Layout';
import { AppTab, WebsiteInputs, IndustryTemplate } from './types';
import { INDUSTRY_TEMPLATES, getIcon } from './constants';
import { generateMasterPrompt } from './services/promptService';
import { 
  Copy, 
  CheckCircle2, 
  RefreshCw, 
  ExternalLink, 
  Sparkles, 
  Rocket,
  ShieldCheck,
  Zap
} from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.BUILDER);
  const [inputs, setInputs] = useState<WebsiteInputs>({
    name: '',
    type: '',
    goal: '',
    audience: '',
    features: '',
    style: '',
    colors: '',
    pages: ''
  });
  const [generatedPrompt, setGeneratedPrompt] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setInputs(prev => ({ ...prev, [name]: value }));
  };

  const handleGenerate = () => {
    const prompt = generateMasterPrompt(inputs);
    setGeneratedPrompt(prompt);
    window.scrollTo({ top: document.getElementById('result-area')?.offsetTop || 0, behavior: 'smooth' });
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLoadTemplate = (template: IndustryTemplate) => {
    setInputs(prev => ({
      ...prev,
      ...template.defaults,
      name: prev.name || `My ${template.label} Website`
    }));
    setActiveTab(AppTab.BUILDER);
  };

  const renderBuilder = () => (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-3 mb-6">
            <Sparkles className="text-indigo-600" size={24} />
            <h2 className="text-xl font-bold text-slate-900">Configure Your Website</h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Website Name</label>
              <input 
                type="text" name="name" value={inputs.name} onChange={handleInputChange}
                className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                placeholder="e.g. Zenith Solutions"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Website Type</label>
              <input 
                type="text" name="type" value={inputs.type} onChange={handleInputChange}
                className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                placeholder="e.g. Agency, SaaS, Portfolio"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Primary Goal</label>
              <input 
                type="text" name="goal" value={inputs.goal} onChange={handleInputChange}
                className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                placeholder="e.g. Bookings, Leads, Sales"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Target Audience</label>
              <input 
                type="text" name="audience" value={inputs.audience} onChange={handleInputChange}
                className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                placeholder="e.g. Small Business Owners"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Key Features</label>
              <textarea 
                name="features" value={inputs.features} onChange={handleInputChange} rows={2}
                className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none resize-none"
                placeholder="e.g. CRM Integration, Booking Calendar"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Brand Style</label>
              <input 
                type="text" name="style" value={inputs.style} onChange={handleInputChange}
                className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                placeholder="e.g. Dark, Modern, Vibrant"
              />
            </div>
            <button 
              onClick={handleGenerate}
              className="w-full prompt-gradient text-white font-bold py-3 rounded-xl shadow-lg hover:shadow-indigo-500/25 transition-all flex items-center justify-center gap-2 mt-4"
            >
              <RefreshCw size={20} /> Generate Master Prompt
            </button>
          </div>
        </div>

        <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
          <h3 className="text-indigo-900 font-bold mb-3 flex items-center gap-2">
            <Rocket size={18} /> Pro Tip
          </h3>
          <p className="text-indigo-800 text-sm leading-relaxed">
            Copy the generated output directly into <strong>Google AI Studio</strong> (Gemini 3 Pro) for the best results. The engine is optimized for multi-turn reasoning and complex functional requirements.
          </p>
        </div>
      </div>

      <div className="lg:col-span-3 space-y-6" id="result-area">
        {generatedPrompt ? (
          <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-full min-h-[600px]">
            <div className="flex justify-between items-center bg-slate-800 px-6 py-4 border-b border-slate-700">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="ml-2 text-slate-400 text-sm font-mono">master_prompt.txt</span>
              </div>
              <button 
                onClick={handleCopy}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${copied ? 'bg-green-500 text-white' : 'bg-indigo-600 hover:bg-indigo-500 text-white'}`}
              >
                {copied ? <CheckCircle2 size={16} /> : <Copy size={16} />}
                {copied ? 'Copied!' : 'Copy to Clipboard'}
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-grow bg-slate-900 font-mono text-slate-300 text-sm leading-relaxed whitespace-pre-wrap">
              {generatedPrompt}
            </div>
            <div className="bg-slate-800 px-6 py-4 text-xs text-slate-500 border-t border-slate-700 italic">
              Ready to paste into Google AI Studio, Lovable, or any no-code platform.
            </div>
          </div>
        ) : (
          <div className="bg-white border-2 border-dashed border-slate-300 rounded-3xl h-full min-h-[400px] flex flex-col items-center justify-center text-center p-8">
            <div className="bg-slate-100 p-6 rounded-full mb-6">
              <Zap className="text-slate-400" size={48} />
            </div>
            <h3 className="text-2xl font-bold text-slate-800 mb-2">Awaiting Instructions</h3>
            <p className="text-slate-500 max-w-sm">
              Fill out the form on the left to architect your professional website prompt. Your output will appear here.
            </p>
          </div>
        )}
      </div>
    </div>
  );

  const renderTemplates = () => (
    <div className="space-y-8">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <h2 className="text-3xl font-extrabold text-slate-900 mb-4">Industry-Specific Blueprints</h2>
        <p className="text-slate-600">
          Kickstart your project with our precision-engineered templates. Each blueprint is designed with domain-specific conversion logic and best practices.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {INDUSTRY_TEMPLATES.map((template) => (
          <div key={template.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-xl hover:border-indigo-200 transition-all group">
            <div className="bg-indigo-50 text-indigo-600 p-3 rounded-xl inline-flex mb-4 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              {getIcon(template.icon)}
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">{template.label}</h3>
            <p className="text-slate-500 text-sm mb-6 line-clamp-3">
              {template.defaults.features}
            </p>
            <div className="space-y-3">
              <button 
                onClick={() => handleLoadTemplate(template)}
                className="w-full bg-slate-900 hover:bg-black text-white py-2.5 rounded-xl font-semibold text-sm transition-all"
              >
                Use this Blueprint
              </button>
              <button 
                onClick={() => {
                   navigator.clipboard.writeText(template.prompt);
                   setCopied(true);
                   setTimeout(() => setCopied(false), 2000);
                }}
                className="w-full bg-slate-50 hover:bg-indigo-50 text-indigo-600 py-2.5 rounded-xl font-semibold text-sm border border-transparent hover:border-indigo-100 transition-all flex items-center justify-center gap-2"
              >
                <Copy size={16} /> Copy Raw Template
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderResources = () => (
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="prompt-gradient p-12 text-white text-center">
          <h2 className="text-4xl font-extrabold mb-4">The Ultimate Tech Stack</h2>
          <p className="text-indigo-100 text-lg">Curated tools for professional AI-driven development.</p>
        </div>
        <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <h3 className="text-xl font-bold flex items-center gap-2"><Sparkles className="text-indigo-600" /> AI Building</h3>
            <div className="space-y-4">
               {[
                 { name: "Google AI Studio", desc: "Best for direct LLM interaction & Gemini Pro.", link: "https://aistudio.google.com" },
                 { name: "Lovable", desc: "Build full-stack web apps with pure natural language.", link: "https://lovable.dev" },
                 { name: "Abacus AI DeepAgent", desc: "Enterprise-grade AI chat and agent development.", link: "#" }
               ].map(tool => (
                 <a key={tool.name} href={tool.link} target="_blank" className="block group p-4 rounded-xl hover:bg-slate-50 transition-colors">
                   <div className="flex justify-between items-center mb-1">
                     <span className="font-bold text-slate-900 group-hover:text-indigo-600">{tool.name}</span>
                     <ExternalLink size={14} className="text-slate-400" />
                   </div>
                   <p className="text-xs text-slate-500">{tool.desc}</p>
                 </a>
               ))}
            </div>
          </div>
          <div className="space-y-6">
            <h3 className="text-xl font-bold flex items-center gap-2"><ShieldCheck className="text-indigo-600" /> Professional Essentials</h3>
             <div className="space-y-4">
               {[
                 { name: "ElevenLabs", desc: "Ultra-realistic AI voiceovers for marketing videos.", link: "#" },
                 { name: "HeyGen", desc: "Best-in-class talking avatar video generation.", link: "#" },
                 { name: "Hostinger", desc: "High-performance web hosting and domain services.", link: "#" }
               ].map(tool => (
                 <a key={tool.name} href={tool.link} target="_blank" className="block group p-4 rounded-xl hover:bg-slate-50 transition-colors">
                   <div className="flex justify-between items-center mb-1">
                     <span className="font-bold text-slate-900 group-hover:text-indigo-600">{tool.name}</span>
                     <ExternalLink size={14} className="text-slate-400" />
                   </div>
                   <p className="text-xs text-slate-500">{tool.desc}</p>
                 </a>
               ))}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 rounded-3xl p-8 text-center border border-slate-800">
         <h3 className="text-white text-2xl font-bold mb-4">Want more Step-by-Step guides?</h3>
         <p className="text-slate-400 mb-8 max-w-lg mx-auto">
           Join our community to stay updated with the latest AI video tools, faceless YouTube channel automation, and prompt engineering tips.
         </p>
         <div className="flex flex-wrap justify-center gap-4">
           <button className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg transition-all">
             Subscribe on YouTube
           </button>
           <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg transition-all">
             Follow Facebook Page
           </button>
         </div>
      </div>
    </div>
  );

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {activeTab === AppTab.BUILDER && renderBuilder()}
      {activeTab === AppTab.TEMPLATES && renderTemplates()}
      {activeTab === AppTab.RESOURCES && renderResources()}
      
      {/* Toast Notification */}
      {copied && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-2 animate-bounce z-[100]">
          <CheckCircle2 size={18} className="text-green-400" />
          <span className="font-semibold text-sm">Prompt copied to clipboard!</span>
        </div>
      )}
    </Layout>
  );
};

export default App;
