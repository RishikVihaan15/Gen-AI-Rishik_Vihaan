
import { WebsiteInputs } from '../types';

export const generateMasterPrompt = (inputs: WebsiteInputs): string => {
  const {
    name,
    type,
    goal,
    audience,
    features,
    style,
    colors,
    socialLinks,
    pages
  } = inputs;

  const prompt = `
# ROLE & MINDSET
You are a Senior Product Designer, Full-Stack Architect, Conversion Copywriter, and No-Code Systems Expert combined.
Your task is to analyze the user’s website idea and generate one final, comprehensive, production-ready response that builds a complete professional website.

# WEBSITE OVERVIEW
- Website Name: ${name || 'A Professional Brand'}
- Website Type: ${type || 'General Business'}
- Primary Goal: ${goal || 'Lead generation and user engagement'}
- Target Audience: ${audience || 'Modern online consumers'}
- Brand Style: ${style || 'Modern, clean, and professional'}
${colors ? `- Color Preference: ${colors}` : ''}
${socialLinks ? `- Social Links: ${socialLinks}` : ''}

# FRONTEND REQUIREMENTS (AUTO-ADAPTIVE)
Build a professional structure appropriate to the website type, including:
- Hero section (value-driven headline + high-impact CTA)
- Supporting sub-headline explaining the UVP
- Trust indicators (badges, stats, social proof)
- Services / Packages / Features (dynamic based on type)
- Visual storytelling sections
- FAQ section for conversion optimization
- Strong Footer with navigation and contact info

# REQUIRED PAGES
Include complete structures and placeholder content for:
${pages ? pages : '- Home, About, Services, Contact, Blog, Privacy Policy'}

# ADMIN DASHBOARD & CMS (MANDATORY)
The website must include a fully editable, user-friendly admin dashboard with:
- CMS for creating, editing, and deleting pages, posts, and custom content types.
- Full content customization (text, images, media).
- Full design customization (themes, colors, fonts, section toggles).
- Media library for asset management.
- SEO controls per page (meta tags, slugs).
- Navigation editor.

# BACKEND LOGIC
- Form submissions storage and management.
- ${features.toLowerCase().includes('booking') ? 'Integrated booking/appointment system with admin approval.' : 'Functional contact and lead capture forms.'}
- Admin protected login system.

# DESIGN & UX
- Fully responsive (mobile-first approach).
- Modern UI with smooth animations.
- Fast loading performance.
- Accessible typography and high contrast.

# FINAL INSTRUCTION
Generate the complete website structure, UI, backend logic, and admin dashboard based on the above requirements. The result must be fully editable, professional, and production-ready.
`;

  return prompt.trim();
};
